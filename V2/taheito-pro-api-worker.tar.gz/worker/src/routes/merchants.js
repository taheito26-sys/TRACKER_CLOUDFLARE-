// ── merchants.js ─────────────────────────────────────────────────────
export async function handleMerchants(c) {
  const path = c.path;

  if (c.method === 'GET' && path === '/api/merchants/me') {
    const m = await c.db.prepare('SELECT * FROM merchants WHERE user_id = ?').bind(c.userId).first();
    return c.json(m || { exists: false });
  }

  if (c.method === 'GET' && path === '/api/merchants/search') {
    const q = c.url.searchParams.get('q') || '';
    const limit = Math.min(parseInt(c.url.searchParams.get('limit') || '20'), 50);
    if (!q.trim()) return c.json({ results: [] });
    const results = await c.db.prepare(`
      SELECT id, display_name, nickname, merchant_type, region, bio, status
      FROM merchants
      WHERE discoverability = 'public' AND status = 'active'
        AND (display_name LIKE ? OR nickname LIKE ? OR id LIKE ?)
      LIMIT ?
    `).bind(`%${q}%`, `%${q}%`, `%${q}%`, limit).all();
    return c.json({ results: results.results });
  }

  if (c.method === 'POST' && path === '/api/merchants') {
    const body = await c.req.json();
    const id = body.merchant_id || crypto.randomUUID();
    await c.db.prepare(`
      INSERT INTO merchants (id, user_id, display_name, nickname, merchant_type, phone, email, region, bio, risk_level, discoverability, default_profit_ratio, created_at, updated_at)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, datetime('now'), datetime('now'))
      ON CONFLICT(id) DO UPDATE SET
        display_name=excluded.display_name, nickname=excluded.nickname, merchant_type=excluded.merchant_type,
        phone=excluded.phone, email=excluded.email, region=excluded.region, bio=excluded.bio,
        discoverability=excluded.discoverability, updated_at=datetime('now')
    `).bind(id, c.userId, body.display_name || '', body.nickname || '', body.merchant_type || 'general',
      body.phone || '', body.email || '', body.region || '', body.bio || '',
      body.risk_level || 'low', body.discoverability || 'public', body.default_profit_ratio || 60).run();
    const merchant = await c.db.prepare('SELECT * FROM merchants WHERE id = ?').bind(id).first();
    return c.json(merchant, 201);
  }

  return c.jsonError(404, 'Merchant route not found');
}

// ── invites.js ───────────────────────────────────────────────────────
export async function handleInvites(c) {
  const path = c.path;
  const actionMatch = path.match(/^\/api\/invites\/([^/]+)\/(accept|reject|withdraw)$/);

  if (c.method === 'GET' && path === '/api/invites') {
    const sent = await c.db.prepare(
      'SELECT * FROM invites WHERE from_merchant = ? ORDER BY created_at DESC'
    ).bind(c.merchantId).all();
    const received = await c.db.prepare(
      'SELECT * FROM invites WHERE to_merchant = ? OR to_identifier = ? ORDER BY created_at DESC'
    ).bind(c.merchantId, c.merchantId).all();
    return c.json({ sent: sent.results, received: received.results });
  }

  if (c.method === 'POST' && path === '/api/invites') {
    const body = await c.req.json();
    const id = crypto.randomUUID();
    const fromMerchant = await c.db.prepare('SELECT display_name, nickname FROM merchants WHERE id = ?').bind(c.merchantId).first();
    await c.db.prepare(`
      INSERT INTO invites (id, from_merchant, to_merchant, to_identifier, from_display_name, from_nickname, purpose, message, created_at, updated_at)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, datetime('now'), datetime('now'))
    `).bind(id, c.merchantId, body.to_merchant_id || null, body.to_identifier || body.to_merchant_id || '',
      fromMerchant?.display_name || '', fromMerchant?.nickname || '',
      body.purpose || '', body.message || '').run();
    return c.json({ id, status: 'pending' }, 201);
  }

  if (c.method === 'PUT' && actionMatch) {
    const [, inviteId, action] = actionMatch;
    const invite = await c.db.prepare('SELECT * FROM invites WHERE id = ?').bind(inviteId).first();
    if (!invite) return c.jsonError(404, 'Invite not found');

    if (action === 'accept') {
      // Create relationship
      const relId = crypto.randomUUID();
      await c.db.batch([
        c.db.prepare('UPDATE invites SET status = ?, updated_at = datetime(\'now\') WHERE id = ?').bind('accepted', inviteId),
        c.db.prepare(`
          INSERT INTO relationships (id, merchant_a, merchant_b, status, created_at, updated_at)
          VALUES (?, ?, ?, 'active', datetime('now'), datetime('now'))
        `).bind(relId, invite.from_merchant, c.merchantId)
      ]);
      return c.json({ invite_id: inviteId, status: 'accepted', relationship_id: relId });
    } else if (action === 'reject') {
      await c.db.prepare('UPDATE invites SET status = ?, updated_at = datetime(\'now\') WHERE id = ?').bind('rejected', inviteId).run();
      return c.json({ invite_id: inviteId, status: 'rejected' });
    } else if (action === 'withdraw') {
      await c.db.prepare('UPDATE invites SET status = ?, updated_at = datetime(\'now\') WHERE id = ?').bind('withdrawn', inviteId).run();
      return c.json({ invite_id: inviteId, status: 'withdrawn' });
    }
  }

  return c.jsonError(404, 'Invite route not found');
}

// ── relationships.js ─────────────────────────────────────────────────
export async function handleRelationships(c) {
  const path = c.path;
  const id = path.match(/^\/api\/relationships\/([^/]+)$/)?.[1];

  if (c.method === 'GET' && path === '/api/relationships') {
    const rels = await c.db.prepare(`
      SELECT r.*,
        ma.display_name AS merchant_a_name, ma.nickname AS merchant_a_nick,
        mb.display_name AS merchant_b_name, mb.nickname AS merchant_b_nick
      FROM relationships r
      JOIN merchants ma ON ma.id = r.merchant_a
      JOIN merchants mb ON mb.id = r.merchant_b
      WHERE r.merchant_a = ? OR r.merchant_b = ?
      ORDER BY r.created_at DESC
    `).bind(c.merchantId, c.merchantId).all();
    return c.json({ relationships: rels.results });
  }

  if (c.method === 'GET' && id) {
    const rel = await c.db.prepare(`
      SELECT r.*, ma.display_name AS merchant_a_name, mb.display_name AS merchant_b_name
      FROM relationships r
      JOIN merchants ma ON ma.id = r.merchant_a
      JOIN merchants mb ON mb.id = r.merchant_b
      WHERE r.id = ? AND (r.merchant_a = ? OR r.merchant_b = ?)
    `).bind(id, c.merchantId, c.merchantId).first();
    if (!rel) return c.jsonError(404, 'Relationship not found');

    const deals = await c.db.prepare(
      'SELECT * FROM deals WHERE relationship_id = ? ORDER BY created_at DESC'
    ).bind(id).all();
    const messages = await c.db.prepare(
      'SELECT * FROM messages WHERE relationship_id = ? ORDER BY created_at DESC LIMIT 100'
    ).bind(id).all();

    return c.json({ relationship: rel, deals: deals.results, messages: messages.results });
  }

  return c.jsonError(404, 'Relationship route not found');
}

// ── messages.js ──────────────────────────────────────────────────────
export async function handleMessages(c) {
  const path = c.path;
  const relId = path.match(/^\/api\/messages\/([^/]+)$/)?.[1];

  if (c.method === 'GET' && relId) {
    const msgs = await c.db.prepare(
      'SELECT * FROM messages WHERE relationship_id = ? ORDER BY created_at ASC'
    ).bind(relId).all();
    // Mark as read
    await c.db.prepare(
      `UPDATE messages SET read_at = datetime('now')
       WHERE relationship_id = ? AND sender_id != ? AND read_at IS NULL`
    ).bind(relId, c.merchantId).run();
    return c.json({ messages: msgs.results });
  }

  if (c.method === 'POST' && path === '/api/messages') {
    const body = await c.req.json();
    if (!body.relationship_id || !body.body) return c.jsonError(400, 'relationship_id and body required');
    const id = crypto.randomUUID();
    const senderName = (await c.db.prepare('SELECT display_name FROM merchants WHERE id = ?').bind(c.merchantId).first())?.display_name || '';
    await c.db.prepare(`
      INSERT INTO messages (id, relationship_id, sender_id, sender_name, body, msg_type, ref_deal_id, created_at)
      VALUES (?, ?, ?, ?, ?, ?, ?, datetime('now'))
    `).bind(id, body.relationship_id, c.merchantId, senderName, body.body, body.msg_type || 'text', body.ref_deal_id || null).run();
    return c.json({ id, sent: true }, 201);
  }

  return c.jsonError(404, 'Message route not found');
}

// ── approvals.js ─────────────────────────────────────────────────────
export async function handleApprovals(c) {
  const path = c.path;
  const actionMatch = path.match(/^\/api\/approvals\/([^/]+)\/(approve|reject)$/);

  if (c.method === 'GET' && path === '/api/approvals') {
    const inbox = await c.db.prepare(
      'SELECT * FROM approvals WHERE reviewer_id = ? ORDER BY created_at DESC'
    ).bind(c.merchantId).all();
    const sent = await c.db.prepare(
      'SELECT * FROM approvals WHERE submitted_by = ? ORDER BY created_at DESC'
    ).bind(c.merchantId).all();
    return c.json({ inbox: inbox.results, sent: sent.results });
  }

  if (c.method === 'POST' && path === '/api/approvals') {
    const body = await c.req.json();
    const id = crypto.randomUUID();
    await c.db.prepare(`
      INSERT INTO approvals (id, submitted_by, reviewer_id, approval_type, ref_type, ref_id, data, created_at)
      VALUES (?, ?, ?, ?, ?, ?, ?, datetime('now'))
    `).bind(id, c.merchantId, body.reviewer_id, body.approval_type, body.ref_type || '', body.ref_id || '', JSON.stringify(body.data || {})).run();
    return c.json({ id, status: 'pending' }, 201);
  }

  if (c.method === 'PUT' && actionMatch) {
    const [, approvalId, action] = actionMatch;
    const newStatus = action === 'approve' ? 'approved' : 'rejected';
    await c.db.prepare(
      `UPDATE approvals SET status = ?, reviewed_at = datetime('now') WHERE id = ? AND reviewer_id = ?`
    ).bind(newStatus, approvalId, c.merchantId).run();
    return c.json({ id: approvalId, status: newStatus });
  }

  return c.jsonError(404, 'Approval route not found');
}

// ── settlements.js ───────────────────────────────────────────────────
export async function handleSettlements(c) {
  const path = c.path;

  if (c.method === 'GET' && path === '/api/settlements') {
    const settlements = await c.db.prepare(`
      SELECT s.* FROM settlements s
      JOIN relationships r ON r.id = s.relationship_id
      WHERE r.merchant_a = ? OR r.merchant_b = ?
      ORDER BY s.created_at DESC
    `).bind(c.merchantId, c.merchantId).all();
    return c.json({ settlements: settlements.results });
  }

  if (c.method === 'POST' && path === '/api/settlements') {
    const body = await c.req.json();
    const id = crypto.randomUUID();
    await c.db.prepare(`
      INSERT INTO settlements (id, relationship_id, deal_ids, gross_amount, fees, net_amount, currency, method, reference, status, created_at)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'pending', datetime('now'))
    `).bind(id, body.relationship_id, JSON.stringify(body.deal_ids || []),
      body.gross_amount, body.fees || 0, body.net_amount || (body.gross_amount - (body.fees || 0)),
      body.currency || 'USDT', body.method || '', body.reference || '').run();
    return c.json({ id, status: 'pending' }, 201);
  }

  return c.jsonError(404, 'Settlement route not found');
}

// ── journal.js ───────────────────────────────────────────────────────
export async function handleJournal(c) {
  const path = c.path;

  if (c.method === 'GET' && path === '/api/journal') {
    const limit = Math.min(parseInt(c.url.searchParams.get('limit') || '100'), 500);
    const offset = parseInt(c.url.searchParams.get('offset') || '0');
    const entries = await c.db.prepare(
      'SELECT * FROM journal WHERE user_id = ? ORDER BY created_at DESC LIMIT ? OFFSET ?'
    ).bind(c.userId, limit, offset).all();
    return c.json({ entries: entries.results });
  }

  if (c.method === 'GET' && path === '/api/journal/balances') {
    const dr = await c.db.prepare(
      'SELECT dr_account AS account, SUM(amount) AS total FROM journal WHERE user_id = ? GROUP BY dr_account'
    ).bind(c.userId).all();
    const cr = await c.db.prepare(
      'SELECT cr_account AS account, SUM(amount) AS total FROM journal WHERE user_id = ? GROUP BY cr_account'
    ).bind(c.userId).all();
    return c.json({ debits: dr.results, credits: cr.results });
  }

  return c.jsonError(404, 'Journal route not found');
}

// ── p2p.js ───────────────────────────────────────────────────────────
export async function handleP2P(c) {
  if (c.method === 'GET' && c.path === '/api/p2p/rates') {
    const sellAvg = await c.kv.get('p2p_sell_avg');
    const buyAvg = await c.kv.get('p2p_buy_avg');
    const sellRaw = await c.kv.get('p2p_sell_raw');
    const buyRaw = await c.kv.get('p2p_buy_raw');
    return c.json({
      sell_avg: sellAvg ? parseFloat(sellAvg) : null,
      buy_avg: buyAvg ? parseFloat(buyAvg) : null,
      sell_data: sellRaw ? JSON.parse(sellRaw) : [],
      buy_data: buyRaw ? JSON.parse(buyRaw) : [],
      cached: true
    });
  }
  return c.jsonError(404, 'P2P route not found');
}

// ── importexport.js ──────────────────────────────────────────────────
export async function handleImportExport(c) {
  // POST /api/import/json — migrate from localStorage
  if (c.method === 'POST' && c.path === '/api/import/json') {
    const body = await c.req.json();
    const { state, merchantState } = body;
    let imported = { batches: 0, trades: 0, customers: 0, suppliers: 0, deals: 0 };

    // Import batches
    if (state?.batches?.length) {
      for (const b of state.batches) {
        await c.db.prepare(`
          INSERT OR IGNORE INTO batches (id, user_id, source, initial_usdt, buy_price_qar, fee_qar, notes, created_at)
          VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        `).bind(b.id, c.userId, b.source || '', b.initialUSDT || 0, b.buyPriceQAR || 0,
          b.feeQAR || 0, b.notes || '', new Date(b.ts || Date.now()).toISOString()).run();
        imported.batches++;
      }
    }

    // Import trades
    if (state?.trades?.length) {
      for (const t of state.trades) {
        await c.db.prepare(`
          INSERT OR IGNORE INTO trades (id, user_id, customer_name, amount_usdt, sell_price_qar, fee_qar, uses_stock, voided, notes, created_at)
          VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        `).bind(t.id, c.userId, t.customer || '', t.amountUSDT || 0, t.sellPriceQAR || 0,
          t.feeQAR || 0, t.usesStock ? 1 : 0, t.voided ? 1 : 0, t.notes || '',
          new Date(t.ts || Date.now()).toISOString()).run();
        imported.trades++;
      }
    }

    // Import customers
    if (state?.customers?.length) {
      for (const cu of state.customers) {
        await c.db.prepare(`
          INSERT OR IGNORE INTO customers (id, user_id, name, phone, tier, notes, created_at)
          VALUES (?, ?, ?, ?, ?, ?, datetime('now'))
        `).bind(cu.id, c.userId, cu.name || '', cu.phone || '', cu.tier || 'C', cu.notes || '').run();
        imported.customers++;
      }
    }

    // Import suppliers
    if (state?.suppliers?.length) {
      for (const su of state.suppliers) {
        await c.db.prepare(`
          INSERT OR IGNORE INTO suppliers (id, user_id, name, phone, typical_price, notes, created_at)
          VALUES (?, ?, ?, ?, ?, ?, datetime('now'))
        `).bind(su.id, c.userId, su.name || '', su.phone || '', su.typicalPrice || 0, su.notes || '').run();
        imported.suppliers++;
      }
    }

    // Run FIFO after import
    if (imported.batches > 0 || imported.trades > 0) {
      const { runFIFO } = await import('../services/fifo.js');
      await runFIFO(c.db, c.userId);
    }

    return c.json({ ok: true, imported });
  }

  // GET /api/export/json — full data export
  if (c.method === 'GET' && c.path === '/api/export/json') {
    const [batches, trades, customers, suppliers, deals, journal, messages] = await Promise.all([
      c.db.prepare('SELECT * FROM batches WHERE user_id = ?').bind(c.userId).all(),
      c.db.prepare('SELECT * FROM trades WHERE user_id = ?').bind(c.userId).all(),
      c.db.prepare('SELECT * FROM customers WHERE user_id = ?').bind(c.userId).all(),
      c.db.prepare('SELECT * FROM suppliers WHERE user_id = ?').bind(c.userId).all(),
      c.db.prepare('SELECT * FROM deals WHERE creator_id = ?').bind(c.merchantId || '').all(),
      c.db.prepare('SELECT * FROM journal WHERE user_id = ?').bind(c.userId).all(),
      c.db.prepare(`SELECT * FROM messages WHERE relationship_id IN
        (SELECT id FROM relationships WHERE merchant_a = ? OR merchant_b = ?)`
      ).bind(c.merchantId || '', c.merchantId || '').all(),
    ]);

    return c.json({
      exported_at: new Date().toISOString(),
      batches: batches.results,
      trades: trades.results,
      customers: customers.results,
      suppliers: suppliers.results,
      deals: deals.results,
      journal: journal.results,
      messages: messages.results
    });
  }

  return c.jsonError(404, 'Import/export route not found');
}
