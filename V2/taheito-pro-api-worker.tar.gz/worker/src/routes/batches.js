/**
 * Batches routes — USDT inventory management
 * Replaces: state.batches in localStorage, addBatch(), deleteBatch(), editBatch()
 */

import { runFIFO, getStockSummary } from '../services/fifo.js';

export async function handleBatches(c) {
  const path = c.path;
  const id = path.match(/^\/api\/batches\/([^/]+)$/)?.[1];

  // GET /api/batches — list batches with remaining USDT
  if (c.method === 'GET' && path === '/api/batches') {
    const summary = await getStockSummary(c.db, c.userId);
    return c.json(summary);
  }

  // GET /api/batches/summary — stock overview (totalStock, WACOP, cost)
  if (c.method === 'GET' && path === '/api/batches/summary') {
    const summary = await getStockSummary(c.db, c.userId);
    return c.json({
      total_stock: summary.totalStock,
      stock_cost: summary.stockCost,
      wacop: summary.wacop,
      batch_count: summary.batches.length,
      open_batches: summary.batches.filter(b => b.remaining_usdt > 0).length
    });
  }

  // POST /api/batches — create batch
  if (c.method === 'POST' && path === '/api/batches') {
    const body = await c.req.json();
    const { source, initial_usdt, buy_price_qar, fee_qar, notes, supplier_id } = body;

    if (!initial_usdt || initial_usdt <= 0) return c.jsonError(400, 'initial_usdt required and must be > 0');
    if (!buy_price_qar || buy_price_qar <= 0) return c.jsonError(400, 'buy_price_qar required and must be > 0');

    const id = crypto.randomUUID();
    await c.db.prepare(`
      INSERT INTO batches (id, user_id, supplier_id, source, initial_usdt, buy_price_qar, fee_qar, notes, created_at)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, datetime('now'))
    `).bind(id, c.userId, supplier_id || null, source || '', initial_usdt, buy_price_qar, fee_qar || 0, notes || '').run();

    // Re-run FIFO since new batch may satisfy previously insufficient trades
    await runFIFO(c.db, c.userId);

    // Audit
    await c.db.prepare(
      `INSERT INTO audit_log (user_id, entity_type, entity_id, action, detail, created_at)
       VALUES (?, 'batch', ?, 'created', ?, datetime('now'))`
    ).bind(c.userId, id, `Batch: ${initial_usdt} USDT @ ${buy_price_qar} QAR`).run();

    const batch = await c.db.prepare('SELECT * FROM batches WHERE id = ?').bind(id).first();
    return c.json(batch, 201);
  }

  // PUT /api/batches/:id — edit batch
  if (c.method === 'PUT' && id) {
    const existing = await c.db.prepare(
      'SELECT * FROM batches WHERE id = ? AND user_id = ?'
    ).bind(id, c.userId).first();
    if (!existing) return c.jsonError(404, 'Batch not found');

    const body = await c.req.json();
    const fields = ['source', 'initial_usdt', 'buy_price_qar', 'fee_qar', 'notes', 'supplier_id', 'status'];
    const updates = [];
    const values = [];

    for (const f of fields) {
      if (body[f] !== undefined) {
        updates.push(`${f} = ?`);
        values.push(body[f]);
      }
    }

    if (updates.length === 0) return c.jsonError(400, 'No fields to update');

    values.push(id, c.userId);
    await c.db.prepare(
      `UPDATE batches SET ${updates.join(', ')} WHERE id = ? AND user_id = ?`
    ).bind(...values).run();

    // Re-run FIFO if amount or price changed
    if (body.initial_usdt !== undefined || body.buy_price_qar !== undefined) {
      await runFIFO(c.db, c.userId);
    }

    const updated = await c.db.prepare('SELECT * FROM batches WHERE id = ?').bind(id).first();
    return c.json(updated);
  }

  // DELETE /api/batches/:id
  if (c.method === 'DELETE' && id) {
    const existing = await c.db.prepare(
      'SELECT * FROM batches WHERE id = ? AND user_id = ?'
    ).bind(id, c.userId).first();
    if (!existing) return c.jsonError(404, 'Batch not found');

    // Check if any allocations reference this batch
    const allocCount = await c.db.prepare(
      'SELECT COUNT(*) as c FROM trade_allocations WHERE batch_id = ?'
    ).bind(id).first();

    if (allocCount.c > 0) {
      return c.jsonError(409, 'Cannot delete batch with active trade allocations. Void the trades first.');
    }

    await c.db.prepare('DELETE FROM batches WHERE id = ?').bind(id).run();

    await c.db.prepare(
      `INSERT INTO audit_log (user_id, entity_type, entity_id, action, detail, created_at)
       VALUES (?, 'batch', ?, 'deleted', ?, datetime('now'))`
    ).bind(c.userId, id, `Deleted batch: ${existing.initial_usdt} USDT`).run();

    return c.json({ ok: true, deleted: id });
  }

  return c.jsonError(404, 'Batch route not found');
}
