export { handleJournal } from './merchants.js';
