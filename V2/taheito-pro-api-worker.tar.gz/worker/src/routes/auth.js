/**
 * Auth routes — Google OAuth token exchange + session management
 * Replaces the client-side Google Sign-In flow in index.html
 */

export async function handleAuth(c) {
  const path = c.path;

  // POST /api/auth/google — exchange Google credential for session
  if (c.method === 'POST' && path === '/api/auth/google') {
    const body = await c.req.json();
    const { credential } = body;
    if (!credential) return c.jsonError(400, 'Missing Google credential');

    // Decode JWT payload (Google ID token)
    // In production, verify with Google's public keys
    let payload;
    try {
      const parts = credential.split('.');
      payload = JSON.parse(atob(parts[1].replace(/-/g, '+').replace(/_/g, '/')));
    } catch (e) {
      return c.jsonError(400, 'Invalid credential');
    }

    const { sub: googleId, email, name, picture } = payload;
    if (!googleId || !email) return c.jsonError(400, 'Invalid token payload');

    // Upsert user
    await c.db.prepare(`
      INSERT INTO users (id, email, display_name, google_id, created_at)
      VALUES (?, ?, ?, ?, datetime('now'))
      ON CONFLICT(google_id) DO UPDATE SET
        email = excluded.email,
        display_name = excluded.display_name
    `).bind(googleId, email, name || email, googleId).run();

    // Create session (30-day expiry)
    const token = crypto.randomUUID() + '-' + crypto.randomUUID();
    const expiresAt = new Date(Date.now() + 30 * 86400000).toISOString();

    await c.db.prepare(
      `INSERT INTO sessions (token, user_id, expires_at, created_at)
       VALUES (?, ?, ?, datetime('now'))`
    ).bind(token, googleId, expiresAt).run();

    // Check if merchant profile exists
    const merchant = await c.db.prepare(
      'SELECT id FROM merchants WHERE user_id = ?'
    ).bind(googleId).first();

    return c.json({
      token,
      expires_at: expiresAt,
      user: { id: googleId, email, name, picture },
      has_merchant_profile: !!merchant,
      merchant_id: merchant?.id || null
    });
  }

  // POST /api/auth/logout
  if (c.method === 'POST' && path === '/api/auth/logout') {
    const authHeader = c.req.headers.get('Authorization');
    if (authHeader && authHeader.startsWith('Bearer ')) {
      const token = authHeader.slice(7).trim();
      await c.db.prepare('DELETE FROM sessions WHERE token = ?').bind(token).run();
    }
    return c.json({ ok: true });
  }

  // GET /api/auth/me
  if (c.method === 'GET' && path === '/api/auth/me') {
    if (!c.userId) return c.jsonError(401, 'Not authenticated');

    const user = await c.db.prepare(
      'SELECT id, email, display_name, role, settings, prefs FROM users WHERE id = ?'
    ).bind(c.userId).first();

    const merchant = await c.db.prepare(
      'SELECT * FROM merchants WHERE user_id = ?'
    ).bind(c.userId).first();

    return c.json({ user, merchant });
  }

  return c.jsonError(404, 'Auth route not found');
}
