export { handleRelationships } from './merchants.js';
