/**
 * Customers routes — replaces state.customers in localStorage
 */
export async function handleCustomers(c) {
  const path = c.path;
  const id = path.match(/^\/api\/customers\/([^/]+)$/)?.[1];

  if (c.method === 'GET' && path === '/api/customers') {
    const customers = await c.db.prepare(`
      SELECT cu.*,
        COALESCE(tm.trade_count, 0) AS trade_count,
        COALESCE(tm.total_usdt, 0) AS total_usdt,
        COALESCE(tm.total_revenue, 0) AS total_revenue,
        COALESCE(tm.total_net, 0) AS net_profit,
        tm.last_trade
      FROM customers cu
      LEFT JOIN (
        SELECT t.customer_id,
          COUNT(*) AS trade_count,
          SUM(t.amount_usdt) AS total_usdt,
          SUM(t.amount_usdt * t.sell_price_qar) AS total_revenue,
          SUM(t.amount_usdt * t.sell_price_qar - COALESCE(a.cost, 0) - t.fee_qar) AS total_net,
          MAX(t.created_at) AS last_trade
        FROM trades t
        LEFT JOIN (SELECT trade_id, SUM(cost_qar) AS cost FROM trade_allocations GROUP BY trade_id) a ON a.trade_id = t.id
        WHERE t.voided = 0
        GROUP BY t.customer_id
      ) tm ON tm.customer_id = cu.id
      WHERE cu.user_id = ?
      ORDER BY cu.name ASC
    `).bind(c.userId).all();
    return c.json({ customers: customers.results });
  }

  if (c.method === 'POST' && path === '/api/customers') {
    const body = await c.req.json();
    if (!body.name?.trim()) return c.jsonError(400, 'Name required');
    const cid = crypto.randomUUID();
    await c.db.prepare(`
      INSERT INTO customers (id, user_id, name, phone, tier, location, daily_limit, notes, created_at)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, datetime('now'))
    `).bind(cid, c.userId, body.name.trim(), body.phone || '', body.tier || 'C', body.location || '', body.daily_limit || 0, body.notes || '').run();
    const customer = await c.db.prepare('SELECT * FROM customers WHERE id = ?').bind(cid).first();
    return c.json(customer, 201);
  }

  if (c.method === 'PUT' && id) {
    const body = await c.req.json();
    const fields = ['name', 'phone', 'tier', 'location', 'daily_limit', 'notes', 'status'];
    const updates = []; const values = [];
    for (const f of fields) { if (body[f] !== undefined) { updates.push(`${f} = ?`); values.push(body[f]); } }
    if (!updates.length) return c.jsonError(400, 'No fields');
    values.push(id, c.userId);
    await c.db.prepare(`UPDATE customers SET ${updates.join(', ')} WHERE id = ? AND user_id = ?`).bind(...values).run();
    const updated = await c.db.prepare('SELECT * FROM customers WHERE id = ?').bind(id).first();
    return c.json(updated);
  }

  if (c.method === 'DELETE' && id) {
    await c.db.prepare('DELETE FROM customers WHERE id = ? AND user_id = ?').bind(id, c.userId).run();
    return c.json({ ok: true, deleted: id });
  }

  return c.jsonError(404, 'Customer route not found');
}

/**
 * Suppliers routes — replaces state.suppliers in localStorage
 */
export async function handleSuppliers(c) {
  const path = c.path;
  const id = path.match(/^\/api\/suppliers\/([^/]+)$/)?.[1];

  if (c.method === 'GET' && path === '/api/suppliers') {
    const suppliers = await c.db.prepare(`
      SELECT su.*,
        COALESCE(bm.batch_count, 0) AS batch_count,
        COALESCE(bm.total_usdt, 0) AS volume_supplied,
        COALESCE(bm.avg_price, 0) AS avg_buy_price,
        bm.last_batch
      FROM suppliers su
      LEFT JOIN (
        SELECT supplier_id,
          COUNT(*) AS batch_count,
          SUM(initial_usdt) AS total_usdt,
          AVG(buy_price_qar) AS avg_price,
          MAX(created_at) AS last_batch
        FROM batches GROUP BY supplier_id
      ) bm ON bm.supplier_id = su.id
      WHERE su.user_id = ?
      ORDER BY su.name ASC
    `).bind(c.userId).all();
    return c.json({ suppliers: suppliers.results });
  }

  if (c.method === 'POST' && path === '/api/suppliers') {
    const body = await c.req.json();
    if (!body.name?.trim()) return c.jsonError(400, 'Name required');
    const sid = crypto.randomUUID();
    await c.db.prepare(`
      INSERT INTO suppliers (id, user_id, name, phone, typical_price, location, notes, created_at)
      VALUES (?, ?, ?, ?, ?, ?, ?, datetime('now'))
    `).bind(sid, c.userId, body.name.trim(), body.phone || '', body.typical_price || 0, body.location || '', body.notes || '').run();
    const supplier = await c.db.prepare('SELECT * FROM suppliers WHERE id = ?').bind(sid).first();
    return c.json(supplier, 201);
  }

  if (c.method === 'PUT' && id) {
    const body = await c.req.json();
    const fields = ['name', 'phone', 'typical_price', 'location', 'notes', 'status'];
    const updates = []; const values = [];
    for (const f of fields) { if (body[f] !== undefined) { updates.push(`${f} = ?`); values.push(body[f]); } }
    if (!updates.length) return c.jsonError(400, 'No fields');
    values.push(id, c.userId);
    await c.db.prepare(`UPDATE suppliers SET ${updates.join(', ')} WHERE id = ? AND user_id = ?`).bind(...values).run();
    const updated = await c.db.prepare('SELECT * FROM suppliers WHERE id = ?').bind(id).first();
    return c.json(updated);
  }

  if (c.method === 'DELETE' && id) {
    await c.db.prepare('DELETE FROM suppliers WHERE id = ? AND user_id = ?').bind(id, c.userId).run();
    return c.json({ ok: true, deleted: id });
  }

  return c.jsonError(404, 'Supplier route not found');
}
