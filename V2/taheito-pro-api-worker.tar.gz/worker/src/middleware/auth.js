/**
 * Auth middleware — validates session token from Authorization header or cookie.
 * Returns { valid, userId, merchantId } or { valid: false }.
 */

export async function validateSession(request, env) {
  let token = null;

  // Check Authorization: Bearer <token>
  const authHeader = request.headers.get('Authorization');
  if (authHeader && authHeader.startsWith('Bearer ')) {
    token = authHeader.slice(7).trim();
  }

  // Fallback: check cookie
  if (!token) {
    const cookie = request.headers.get('Cookie') || '';
    const match = cookie.match(/session=([^;]+)/);
    if (match) token = match[1];
  }

  if (!token) return { valid: false };

  try {
    const session = await env.DB.prepare(
      `SELECT s.user_id, m.id AS merchant_id
       FROM sessions s
       LEFT JOIN merchants m ON m.user_id = s.user_id
       WHERE s.token = ? AND s.expires_at > datetime('now')`
    ).bind(token).first();

    if (!session) return { valid: false };

    return {
      valid: true,
      userId: session.user_id,
      merchantId: session.merchant_id || null
    };
  } catch (e) {
    console.error('Auth check error:', e.message);
    return { valid: false };
  }
}
